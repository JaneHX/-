var codes; // 暂存随机获取的验证码
function changeCode() {
	var arr = new Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
	codes = "";
	for(var i = 0; i < 4; i++) {
		var r = parseInt(Math.random() * arr.length);
		codes += arr[r];
	}
	$("#code").val(codes);
}
changeCode();
$("#code").click(changeCode); // 点击切换验证码
$("#confirm").click(function() {
	if($("#code").css("display") == "none") {
		// 如果验证码未出现，不可点击确定按钮
		$(this).attr("disabled", "disabled");
		return;
	}
	var txtCode = $("#obtainCode").val().toUpperCase();
	if(txtCode == " ") {
		alert("请输入验证码！");
		changeCode();
	} else if(txtCode != $("#code").val().toUpperCase()) {
		alert("验证码输入错误！请重新输入！");
		changeCode();
		$("#obtainCode").val("");
	} else if(txtCode != $("#code").val()) {
		alert("验证码正确！");
	}
});
$("#obtainCode").focus(function() {
	if($(this).attr("inital") == "true") {
		$(this).val(" "); // 初始聚集时清空占位字符
	}
	$(this).attr("inital", "false");
});
$("#obtainCode").click(function() {
	$("#code").css("display", "inline-block");
});
// 监控问卷说明的字数
function titleIntr() {
	var text = $("#title_intr").val();
	var counter = text.length;
	$("#numtj var").text(counter);
	$(document).keyup(function() {
		var text = $("#title_intr").val();
		var counter = text.length;
		$("#name_word").text(counter);
	});
}
titleIntr();
// 标题部分
$(".title").click(function() {
	$(".title-cover").css("display", "block");
	$(".title-cover .main .survey").val($(".title h1").html());
	$(".title-cover .btn").click(function() {
		$(".title h1").html($(".survey").val());
		$(".title span").html($("textarea#title_intr").val());
		$(".title-cover").css("display", "none");
	});
	$(".main #close").click(function() {
		$(".title-cover").css("display", "none");
	});
});
// 添加题目
var number = 0;
$(".Qlist li").click(function() {
	number++;
	if ($(this).attr("class")== "single") {
		var newOption = $('<div class="single-choice padding">' +
						'<div class="edit-main">' +
							'<h4><span class="Qnum">' + number + '</span>、<span class="question"></span>&nbsp;<span style="color: red;">*</span></h4>' +
							'<ul>' +
								'<li data-id="0"><input type="radio" name="single"/>&nbsp;<span></span></li>' +
								'<li data-id="1"><input type="radio" name="single"/>&nbsp;<span></span></li>' +
							'</ul>' +
							'<br /><hr />' +
						'</div>' +
						'<div class="operation">'+
							'<span class="operation-edit">编辑</span>'+
							'<span class="operation-del">删除</span>'+
						'</div>'+
						'<div class="single-edit padding">' +
							'<div class="edit-title">' +
								'<p>标题</p>' +
								'<textarea rows="4" class="padding">在此输入问题标题</textarea>' +
							'</div>' +
							'<p>当前题型：<span style="font-weight: bold;">单选题</span></p>' +
							'<div class="edit-option">' +
								'<p>选项</p>' +
								'<ul>' +
									'<li data-id="0">' +
										'<input type="text" value="选项1" />' +
										'<span>删除选项</span>'+
									'</li>' +
									'<li data-id="1">' +
										'<input type="text" value="选项2" />'+
										'<span>删除选项</span>'+
									'</li>' +
								'</ul>' +
								'<div class="add-option"><span>添加选项</span></div>' +
							'</div>' +
							'<div class="finish-edit">完成编辑</div>' +
						'</div>' +
				'</div>');
	}else if ($(this).attr("class") == "double") {
		var newOption = $('<div class="double-choice padding">' +
						'<div class="edit-main">' +
							'<h4><span class="Qnum">' + number + '</span>、<span class="question"></span>&nbsp;<span style="color: red;">*</span><span style="color:blue;font-weight:normal">[多选题]</span></h4>' +
							'<ul>' +
								'<li data-id="0"><input type="checkbox" name="double"/>&nbsp;<span></span></li>' +
								'<li data-id="1"><input type="checkbox" name="double"/>&nbsp;<span></span></li>' +
							'</ul>' +
							'<br /><hr />' +
						'</div>' +
						'<div class="operation">'+
							'<span class="operation-edit">编辑</span>'+
							'<span class="operation-del">删除</span>'+
						'</div>'+
						'<div class="double-edit padding">' +
							'<div class="edit-title">' +
								'<p>标题</p>' +
								'<textarea rows="4" class="padding">在此输入问题标题</textarea>' +
							'</div>' +
							'<p>当前题型：<span style="font-weight: bold;">多选题</span></p>' +
							'<div class="edit-option">' +
								'<p>选项</p>' +
								'<ul>' +
									'<li data-id="0">' +
										'<input type="text" value="选项1" />' +
										'<span>删除选项</span>'+
									'</li>' +
									'<li data-id="1">' +
										'<input type="text" value="选项2" />'+
										'<span>删除选项</span>'+
									'</li>' +
								'</ul>' +
								'<div class="add-option"><span>添加选项</span></div>' +
							'</div>' +
							'<div class="finish-edit">完成编辑</div>' +
						'</div>' +
				'</div>');
	}
	
	$(".subject").append(newOption);
	$(".single-choice .question").html($(".single-edit textarea").val());
	$(".double-choice .question").html($(".double-edit textarea").val());
	// 题目
	keyup($(".single-edit textarea"),$(".single-choice .question"));
	keyup($(".double-edit textarea"),$(".double-choice .question"))
	function keyup(obj1,obj2){
		obj1.keyup(function() {
			obj2.html(obj1.val());
		});
	}
	
	// 同步选项内容 函数
	function optionContent(obj1,obj2,obj3) {
		obj1.each(function(index, element) {
			obj2.eq(index).html($(this).val());
			$(this).keyup(function() {
				var data_id=$(this).parent().attr("data-id");
				for (var i = 0; i < obj3.length; i++) {
					if (obj3.eq(i).attr("data-id")==data_id) {
						obj3.eq(i).children().html($(this).val());
					}
				}
			});
		});
	}
	// 删除选项 函数
	function delOption(obj1,obj2,obj3){
		obj1.click(function(){
			if (obj2.length == 1) {
				return;
			}
			var data_id=$(this).parent().attr("data-id");
			$(this).parent().remove();
			for (var i = 0; i < obj3.length; i++) {
				if (obj3.eq(i).attr("data-id")==data_id) {
					obj3.eq(i).remove();
				}
			}
			obj2.length--;
		});
	}
// 单选题
	// 添加选项
	optionContent($(".single-choice .edit-option ul li input"),$(".single-choice .edit-main ul li span"),$(".single-choice .edit-main ul li"));
	delOption($(".single-choice .edit-option ul li span"),$(".single-choice .edit-option ul li"),$(".single-choice .edit-main ul li"));
	var optionNum = 2; // 默认有两个选项
	var single_dataId=1;
	$(".single-choice .add-option").click(function() {
		optionNum++;
		single_dataId++;
		var newOptionLi = $('<li data-id="'+single_dataId+'">' +
								'<input type="text" value="选项'+optionNum+'" />'+
								'<span>删除选项</span>'+
							'</li>');
		var newMainLi = $('<li data-id="'+single_dataId+'"><input type="radio" name="1"/>&nbsp;<span></span></li>');
		$(".single-choice .edit-option ul").append(newOptionLi);
		$(".single-choice .edit-main ul").append(newMainLi);
		optionContent($(".single-choice .edit-option ul li input"),$(".single-choice .edit-main ul li span"),$(".single-choice .edit-main ul li"));
		delOption($(".single-choice .edit-option ul li span"),$(".single-choice .edit-option ul li"),$(".single-choice .edit-main ul li"));
	});
	
// 多选题
	optionContent($(".double-choice .edit-option ul li input"),$(".double-choice .edit-main ul li span"),$(".double-choice .edit-main ul li"));
	delOption($(".double-choice .edit-option ul li span"),$(".double-choice .edit-option ul li"),$(".double-choice .edit-main ul li"));	
	var db_dataId=1;
	$(".double-choice .add-option").click(function() {
		optionNum++;
		db_dataId++;
		var newOptionLi = $('<li data-id="'+db_dataId+'">' +
								'<input type="text" value="选项'+optionNum+'" />'+
								'<span>删除选项</span>'+
							'</li>');
		var newMainLi = $('<li data-id="'+db_dataId+'"><input type="checkbox" name="double"/>&nbsp;<span></span></li>');
		$(".double-choice .edit-option ul").append(newOptionLi);
		$(".double-choice .edit-main ul").append(newMainLi);
		// 同步内容
		optionContent($(".double-choice .edit-option ul li input"),$(".double-choice .edit-main ul li span"),$(".double-choice .edit-main ul li"));
		// 同步删除
		delOption($(".double-choice .edit-option ul li span"),$(".double-choice .edit-option ul li"),$(".double-choice .edit-main ul li"));
	});
// 完成编辑
	$(".finish-edit").click(function(){
		$(this).parent().css("display","none");
		$(this).parent().parent().css("border","1px transparent solid");
		$(this).parent().parent().hover(function(){
			$(this).css("border","1px orange solid");
			$(this).children(".operation").css("opacity","1");
		},function(){
			$(this).css("border","1px transparent solid");
			$(this).children(".operation").css("opacity","0");
		});
		$(".operation").click(function(){
			
		})
	})
	
	
})

