

var sign;
$(".sign").click(function() {
	sign = $(this).val();
})
	// 登录
$(".content-main #userLogin").click(function() {
	$.ajax({
		type: "get",
		url: "login.php",
		async: true,
		data: {
			user: $("#user").val(),
			pass: $("#pass").val(),
			sign:sign,
		},
		dataType: "json",
		success: function(obj) {
			if(obj.err == "0") {
				alert(obj.msg);
				setCookie("user", $("#user").val(), 1);
				window.location.href = "homePage.html";
			}else{
				alert(obj.msg);
			}
		}
	});
})

// 设置cookie的函数
function setCookie(name, value, day) {
	var nowTime = new Date();
	nowTime.setDate(nowTime.getDate() + day);
	document.cookie = name + "=" + value + "; expires=" + nowTime + "; path=/";
}
// 获取cookie函数
function getCookie(name) {
	var cookies = document.cookie;
	//先把各个名值对拆开
	var arr = cookies.split("; ") // 利用符号分割
		// 把名和值拆开
	for(var i = 0; i < arr.length; i++) {
		var arr2 = arr[i].split("=");
		if(arr2[0] == name) {
			return arr2[1];
		}
	}
}
// 清除cookie
function removeCookie(name) {
	setCookie(name, ".", -1);
}

// 已登录
if(getCookie("user")) {
	$(".login-register").css("display", "none");
	$(".welcome").css("display", "block");
	$(".user").html(getCookie("user"));
}

// 退出登录
$("#exit").click(function() {
	removeCookie("user");
	$(".welcome").css("display", "none");
	$(".login-register").css("display", "block");
	location.href = "../html/homePage.html"
		//	history.go(-1); // 退出登录

});