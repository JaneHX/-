<?php
	mysql_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);
	mysql_select_db(SAE_MYSQL_DB);
	mysql_query("set names utf8");
	date_default_timezone_set("PRC");	
	$user = $_COOKIE["user"];
	$questionnaireName = $_GET["questionnaireName"];
	$sql = "SELECT * FROM userQuestionnaire WHERE user='{$user}' AND questionnaireName='{$questionnaireName}'";
	$result = mysql_query($sql);
	if(mysql_num_rows($result)>0){// 已经存储
		echo '{"error":"1","msg":"问卷已经存在！"}';
	}else{
		$sql= "INSERT INTO userQuestionnaire (id,user,questionnaireName) VALUES (NULL,'{$user}','{$questionnaireName}')";
		$result = mysql_query($sql);
		if(mysql_affected_rows()>0){
			echo '{"error":"0","msg":"存储成功！"}';
		}else{
			echo '{"error":"1","msg":"存储失败！"}';
		}
	}
?>