<?php
	mysql_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);
	mysql_select_db(SAE_MYSQL_DB);
	mysql_query("set names utf8");
	date_default_timezone_set("PRC");	
	
	$user = $_GET["user"];
	$pass = $_GET["pass"];
	$sign = $_GET["sign"];
	$sql = "SELECT * FROM user WHERE mobile='{$user}' or nickname='{$user}'";
	$result = mysql_query($sql);
	if(mysql_num_rows($result)>0){ // 有该用户
		$arr = mysql_fetch_assoc($result);
		if($arr["pass"] == $pass){
			if($arr["sign"] == $sign){ // 账号类型正确
				echo '{"err":"0","msg":"登录成功"}';
			}else{
				echo '{"err":"1","msg":"账号类型错误"}';
			}
		}else{
			echo '{"err":"1","msg":"密码错误"}';
		}
	}else{ // 没有这个用户
		echo '{"err":"0","msg":"该用户不存在"}';
	}
?>	