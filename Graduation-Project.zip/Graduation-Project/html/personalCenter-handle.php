<?php
	mysql_connect(SAE_MYSQL_HOST_M . ':' . SAE_MYSQL_PORT, SAE_MYSQL_USER, SAE_MYSQL_PASS);
	mysql_select_db(SAE_MYSQL_DB);
	mysql_query("set names utf8");
	date_default_timezone_set("PRC");
	$user = $_COOKIE["user"];
	$nickname = $_GET["nickname"];
	$name = $_GET["name"];
	$sex = $_GET["sex"];
	$birthday=implode("-",$_GET["birthday"]);
	$academy = $_GET["academy"];
	$profession= $_GET["profession"];
	$address = $_GET["address"];
	$email = $_GET["email"];
	$sql = "UPDATE user SET nickname='{$nickname}',name='{$name}',sex='{$sex}',birthday='{$birthday}',academy='{$academy}',profession='{$profession}',address='{$address}',email='{$email}' WHERE mobile='{$user}'";
	$result = mysql_query($sql);
	if(mysql_affected_rows()>0){
		echo '{"err":"0","msg":"保存成功"}';
	}else{
		echo '{"err":"1","msg":"保存失败"}';
	}
?>