<?php
	mysql_connect(SAE_MYSQL_HOST_M . ':' . SAE_MYSQL_PORT, SAE_MYSQL_USER, SAE_MYSQL_PASS);
	mysql_select_db(SAE_MYSQL_DB);
	mysql_query("set names utf8");
	date_default_timezone_set("PRC");
	$user = $_COOKIE["user"];
	$sql = "SELECT nickname,name,sex,birthday,academy,profession,address,email FROM user WHERE mobile='{$user}'";
	$result = mysql_query($sql);
	if(mysql_affected_rows()>0){
		$array = mysql_fetch_assoc($result);
	}
	var_dump($array);
	$sql="SELECT birthday FROM user WHERE mobile='{$user}' AND birthday!=''";
	$re=mysql_query($sql);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>个人中心Personal Center</title>
		<link rel="stylesheet" href="../css/head-foot.css">
		<style>
			* {
				margin: 0;
				padding: 0;
			}
			
			/*html,
			body {
				height: 100%;
			}*/
			
			ul {
				list-style: none;
			}
			
			a {
				text-decoration: none;
			}
			
			body {

				background: url("../img/personal_bg.png") no-repeat;
				background-size: 100% 100%;
			}
			
			@media screen and (max-width: 1400px) {
				body {
					background-size: 1404px 100%;
				}
			}
			/*中间部分*/
			
			.personal-content {
				width: 100%;
				min-width: 1400px;
				height: 700px;
			}
			
			.personal-main {
				width: 90%;
				height: 100%;
				min-width: 1400px;
				margin: 0 auto;
				position: relative;
			}
			
			.information {
				margin-left: 250px;
			}
			
			.information li {
				width: 170px;
				font-size: 22px;
				color: white;
				padding: 10px 12px;
				background-color: #e7a161;
				text-align: center;
				border-radius: 10px;
				margin: 20px 0;
				cursor: pointer;
			}
			
			section {
				position: relative;
				left: 470px;
				top: -210px;
				border-left: 2px #e7a161 solid;
				padding: 50px;
				width: 800px;
				height: 700px;
				box-sizing: border-box;
				display: none;
			}
			
			.info ul li {
				margin-bottom: 20px;
			}
			
			.info lable {
				display: inline-block;
				vertical-align: middle;
				text-align: right;
				width: 90px;
			}
			
			.info lable span {
				color: red;
			}
			
			.info input.text {
				width: 200px;
				height: 25px;
				border-radius: 5px;
				border: none;
				border: 1px gray solid;
				outline: none;
			}
			
			.info input.text:focus {
				border: 1px orange solid;
			}
			
			#head {
				width: 72px;
				border-radius: 50%;
				vertical-align: middle;
			}
			
			.info button {
				width: 80px;
				height: 30px;
				font-size: 18px;
				color: white;
				background-color: orange;
				border: none;
				border-radius: 7px;
				margin-left: 130px;
				margin-top: 20px;
				outline: none;
				cursor: pointer;
			}
			
			.info button:hover {
				background-color: #d47513;
			}
			
			.create-questionnaire,
			.write-questionnaire {
				padding-top: 0;
			}
			
			.create-questionnaire h3,
			.write-questionnaire h3 {
				border: 2px #7c4698 solid;
				padding: 2px 0;
				width: 130px;
				text-align: center;
				border-radius: 5px;
				color: #585757;
				font-size: 20px;
			}
			
			.questionnaire {
				width: 700px;
				height: 590px;
			}
			
			.questionnaire p {
				text-align: center;
				color: #757474;
			}
			
			#goCreate {
				background-color: #ad8bbf;
				width: 120px;
				text-align: center;
				color: white;
				font-size: 18px;
				padding: 10px 12px;
				border-radius: 10px;
				margin-top: 10px;
				margin-left: 40%;
			}
			
			#goCreate img {
				width: 20px;
				height: 20px;
				vertical-align: middle;
			}
			
			#goCreate a {
				vertical-align: middle;
				color: white;
			}
		</style>
	</head>

	<body>
		<!--顶部-->
		<header class="home">
			<nav>
				<a href="homePage.html">
					<img src="../img/LOGO-02.png" alt="" title="点击LOGO进入首页">
				</a>
				<ul class="nav" style="left: 36%;">
					<li>
						<a href="homePage.html">
							<p>首页</p>
							<p>Home Page</p>
						</a>
					</li>
					<li>
						<a href="questionnaireCenter.html">
							<p>问卷中心</p>
							<p>Questionnaire Center</p>
						</a>
					</li>
					<li>
						<a href="personalCenter.php" style="color: #d47513;">
							<p>个人中心</p>
							<p>Personal Center</p>
						</a>
					</li>
				</ul>
				<ul class="login-register">
					<li id="login">
						<a href="login.html">
							<p>登录</p>
							<p style="font-size: 12px;">Login</p>
						</a>
					</li>
					<li id="register">
						<a href="register.html">
							<p>注册</p>
							<p style="font-size: 12px;">Register</p>
						</a>
					</li>
				</ul>
				<ul class="welcome" style="display: none;">
					<li title="点击进入个人中心">
						<img src="../img/head.jpg" alt="" class="headImg" />
						<span class="user">18012079325</span>
					</li>
					<li class="svg-wrapper">
						<svg height="25" width="50" xmlns="http://www.w3.org/2000/svg">
							<rect id="shape" height="25" width="50"></rect>
						</svg>
						<div class="text" id="exit">
							<span>退出</span>
						</div>
					</li>
				</ul>
			</nav>
		</header>
		<!--顶部end -->
		<hr style="border: none;border-top: 2px grey solid;min-width: 1400px">
		<!--中间部分-->
		<div class="personal-content">
			<div class="personal-main">
				<ul class="information">
					<li style="color:#7d4697">基本资料</li>
					<li>我创建的问卷</li>
					<li>我填写的问卷</li>
				</ul>
				<!-- 基本信息 -->
				<section class="info" style="display: block;">
					<ul>
						<li>
							<lable>头像：</lable>
							<img src="../img/head.jpg" alt="" id="head">
						</li>
						<li>
							<lable>昵称：</lable>
							<input type="text" class="text" id='nickname' value="<?php echo $array["nickname"]; ?>">
						</li>
						<!--<li>
							<lable><span>*</span>手机号码：</lable>
							<input type="text" class="text" id="mobile">
						</li>-->
						<li>
							<lable>真实姓名：</lable>
							<input type="text" class="text" id="name" value="<?php echo $array["name"]; ?>">
						</li>
						<li>
							<lable>性别：</lable>&nbsp;
							<select name="sex" id="sex" class="sex">
								<option value="0"></option>
								<option value="男">男</option>
								<option value="女">女</option>
							</select>
						</li>
						<li>
							<lable>生日：</lable>
							<span class="birthday">
								<select name="year" id="year" class="year">
									<option value="0">年</option>
									<option value="1901">1901</option>
									<option value="1902">1902</option>
									<option value="1903">1903</option>
									<option value="1904">1904</option>
									<option value="1905">1905</option>
									<option value="1906">1906</option>
									<option value="1907">1907</option>
									<option value="1908">1908</option>
									<option value="1909">1909</option>
									<option value="1910">1910</option>
									<option value="1911">1911</option>
									<option value="1912">1912</option>
									<option value="1913">1913</option>
									<option value="1914">1914</option>
									<option value="1915">1915</option>
									<option value="1916">1916</option>
									<option value="1917">1917</option>
									<option value="1918">1918</option>
									<option value="1919">1919</option>
									<option value="1920">1920</option>
									<option value="1921">1921</option>
									<option value="1922">1922</option>
									<option value="1923">1923</option>
									<option value="1924">1924</option>
									<option value="1925">1925</option>
									<option value="1926">1926</option>
									<option value="1927">1927</option>
									<option value="1928">1928</option>
									<option value="1929">1929</option>
									<option value="1930">1930</option>
									<option value="1931">1931</option>
									<option value="1932">1932</option>
									<option value="1933">1933</option>
									<option value="1934">1934</option>
									<option value="1935">1935</option>
									<option value="1936">1936</option>
									<option value="1937">1937</option>
									<option value="1938">1938</option>
									<option value="1939">1939</option>
									<option value="1940">1940</option>
									<option value="1941">1941</option>
									<option value="1942">1942</option>
									<option value="1943">1943</option>
									<option value="1944">1944</option>
									<option value="1945">1945</option>
									<option value="1946">1946</option>
									<option value="1947">1947</option>
									<option value="1948">1948</option>
									<option value="1949">1949</option>
									<option value="1950">1950</option>
									<option value="1951">1951</option>
									<option value="1952">1952</option>
									<option value="1953">1953</option>
									<option value="1954">1954</option>
									<option value="1955">1955</option>
									<option value="1956">1956</option>
									<option value="1957">1957</option>
									<option value="1958">1958</option>
									<option value="1959">1959</option>
									<option value="1960">1960</option>
									<option value="1961">1961</option>
									<option value="1962">1962</option>
									<option value="1963">1963</option>
									<option value="1964">1964</option>
									<option value="1965">1965</option>
									<option value="1966">1966</option>
									<option value="1967">1967</option>
									<option value="1968">1968</option>
									<option value="1969">1969</option>
									<option value="1970">1970</option>
									<option value="1971">1971</option>
									<option value="1972">1972</option>
									<option value="1973">1973</option>
									<option value="1974">1974</option>
									<option value="1975">1975</option>
									<option value="1976">1976</option>
									<option value="1977">1977</option>
									<option value="1978">1978</option>
									<option value="1979">1979</option>
									<option value="1980">1980</option>
									<option value="1981">1981</option>
									<option value="1982">1982</option>
									<option value="1983">1983</option>
									<option value="1984">1984</option>
									<option value="1985">1985</option>
									<option value="1986">1986</option>
									<option value="1987">1987</option>
									<option value="1988">1988</option>
									<option value="1989">1989</option>
									<option value="1990">1990</option>
									<option value="1991">1991</option>
									<option value="1992">1992</option>
									<option value="1993">1993</option>
									<option value="1994">1994</option>
									<option value="1995">1995</option>
									<option value="1996">1996</option>
									<option value="1997">1997</option>
									<option value="1998">1998</option>
									<option value="1999">1999</option>
									<option value="2000">2000</option>
									<option value="2001">2001</option>
									<option value="2002">2002</option>
									<option value="2003">2003</option>
									<option value="2004">2004</option>
									<option value="2005">2005</option>
									<option value="2006">2006</option>
									<option value="2007">2007</option>
									<option value="2008">2008</option>
									<option value="2009">2009</option>
									<option value="2010">2010</option>
									<option value="2011">2011</option>
									<option value="2012">2012</option>
									<option value="2013">2013</option>
									<option value="2014">2014</option>
									<option value="2015">2015</option>
									<option value="2016">2016</option>
									<option value="2017">2017</option>
								</select>
								<select name="month" id="month" class="month">
									<option value="0">月</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
								</select>
								<select name="day" id="day" class="day">
									<option value="0">日</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
									<option value="13">13</option>
									<option value="14">14</option>
									<option value="15">15</option>
									<option value="16">16</option>
									<option value="17">17</option>
									<option value="18">18</option>
									<option value="19">19</option>
									<option value="20">20</option>
									<option value="21">21</option>
									<option value="22">22</option>
									<option value="23">23</option>
									<option value="24">24</option>
									<option value="25">25</option>
									<option value="26">26</option>
									<option value="27">27</option>
									<option value="28">28</option>
									<option value="29">29</option>
									<option value="30">30</option>
									<option value="31">31</option>
								</select>
							</span>
						</li>
						<li>
							<lable><span>*</span>所在院校：</lable>
							<input type="text" class="text" id="academy" value="<?php echo $array["academy"]; ?>" >
						</li>
						<li>
							<lable><span>*</span>专业：</lable>
							<input type="text" class="text" id="profession" value="<?php echo $array["profession"]; ?>">
						</li>
						<li>
							<lable>居住地：</lable>
							<input type="text" class="text" id="address" value="<?php echo $array["address"]; ?>">
						</li>
						<li>
							<lable><span>*</span>邮箱地址：</lable>
							<input type="text" class="text" id="email" value="<?php echo $array["email"]; ?>">
						</li>
					</ul>
					<button>保存</button>
				</section>
				<!--创建的问卷-->
				<section class="create-questionnaire">
					<h3>创建目录</h3>
					<br>
					<hr style="width: 133px;border: none;border-top: 3px #e7a161 solid"><br>
					<div class="questionnaire">
						<img src="../img/笑脸-02.png" alt="" style="width: 138px;height: 138px;margin-left: 40%;margin-top: 15%;">
						<p>未创建相关问卷</p>
						<div id="goCreate">
							<img src="../img/加号.png" alt="">
							<a href="createQuestionnaire.html">现在去创建</a>
						</div>
					</div>
				</section>
				<!--填写的问卷-->
				<section class="write-questionnaire">
					<h3>填写目录</h3>
					<br>
					<hr style="width: 133px;border: none;border-top: 3px #e7a161 solid"><br>
					<div class="questionnaire">
						<img src="../img/笑脸-02.png" alt="" style="width: 138px;height: 138px;margin-left: 40%;margin-top: 15%;">
						<p>未填写相关问卷</p>
					</div>
				</section>
			</div>
		</div>
		<!--中间end-->
	</body>
	<script src="../js/jquery-1.11.2.min.js"></script>
	<script src="../js/login_set.js"></script>
	<script>
		<?php
			if(mysql_num_rows($re)>0){
				$a=mysql_fetch_row($re);
				$str = implode("", $a);
				$birthday=explode("-", $str);
		?>		
				$("#year").val("<?php echo $birthday[0]?>"); 
				$("#month").val("<?php echo $birthday[1]?>"); 
				$("#day").val("<?php echo $birthday[2]?>"); 
		<?php
			}
		?>	
		<?php 
			 if($array["sex"]!=""){
		?>
			 	$("#sex").val("<?php echo $array["sex"] ?>");	
		<?php
			 }
		?>
		var birthdayArr = [];
		$(".info button").click(function() {
			birthdayArr[0]=$("#year").val();
			birthdayArr[1]=$("#month").val();
			birthdayArr[2]=$("#day").val();
			$.ajax({
			     type:"get",
			     url:"personalCenter-handle.php",
			     async:true,
			     data:{
			     	nickname:$("#nickname").val(),
			     	name:$("#name").val(),
			     	sex:$("#sex").val(),
			     	birthday:birthdayArr,
			     	academy:$("#academy").val(),
			     	profession:$("#profession").val(),
			     	address:$("#address").val(),
			     	email:$("#email").val()
			     },
			     dataType:"json",
			     success:function(obj){
					alert(obj.msg);
			     }
			 });
			
		});
		//个人中心tab切换
		$(".information li").click(function() {
			var index = $(this).index();
			//        先清除
			$(".information li").css("color", "white");
			$("section").css("display", "none");
			//        后设置
			$(this).css("color", "#7d4697");
			$("section").eq(index).css("display", "block");
		})
	</script>
</html>