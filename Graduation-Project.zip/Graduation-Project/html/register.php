<?php
    mysql_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);
	mysql_select_db(SAE_MYSQL_DB);
	mysql_query("set names utf8");
	date_default_timezone_set("PRC");	
    $mobile = $_GET["mobile"];
    $pass = $_GET["pass"];
	$sign=$_GET["sign"];
    $sql = "SELECT * FROM user WHERE mobile='{$mobile}'";
    $result = mysql_query($sql);
    if(mysql_num_rows($result)>0){
    	// 数据库中已存在该用户
    		echo '{"err":"1","msg":"该用户已被注册"}';
    }else{
    	// 未被注册
    	$sql = "INSERT INTO user (id,mobile,pass,sign,nickname) VALUE (NULL,'{$mobile}','{$pass}','{$sign}','{$mobile}')";
		$result = mysql_query($sql);
		if(mysql_affected_rows()>0){
			echo '{"err":"0","msg":"注册成功"}';
		}else{
			echo '{"err":"1","msg":"注册失败"}';
		}
    }


?>